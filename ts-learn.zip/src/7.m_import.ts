/* import { name, getName } from "./7.m_export";
import fs from 'fs'
getName(name)
fs.readFileSync('./') */
const myModule = require('./7.m_export')
console.log(myModule)