import {createDeck, printDeck} from './func'
var deck = createDeck()
printDeck(deck)