/* 
export const name = "曾世鑫"

export function getName(name:string):void {
  console.log(name)
} */
module.exports = {
  abc:123
}